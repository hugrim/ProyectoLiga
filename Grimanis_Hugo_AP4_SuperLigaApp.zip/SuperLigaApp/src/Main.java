/**
 * 
 */

import com.superLiga.controlador.LigaControlador;

/**
 * @author Hugo Grimanis
 *
 */
public class Main {

	public static void main (String[]args){
		
		LigaControlador ligaControlador = new LigaControlador();
		ligaControlador.msotrarMenu();
	    }	    
	}
